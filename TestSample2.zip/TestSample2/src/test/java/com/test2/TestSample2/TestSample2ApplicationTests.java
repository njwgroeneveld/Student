package com.test2.TestSample2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSample2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
